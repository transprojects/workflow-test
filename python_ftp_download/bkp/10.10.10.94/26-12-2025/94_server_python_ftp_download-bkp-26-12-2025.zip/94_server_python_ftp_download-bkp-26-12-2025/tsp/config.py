local_downloaded_path = r'J:\AUTOMATION-SYSTEM\TSP-CLIENT-PORTAL'

#dDatabase details
db_host = '10.10.10.110'
db_user = 'root'
db_password = 'root@123'   #"root@123"
db_database = 'workflow'    #"workflow"

#Mail Details
SMTP_SERVER = "smtp.office365.com"
SMTP_PORT = 587
SENDER_EMAIL = "techsupport@transforma.in"
SENDER_PASSWORD = "Tr@n$!t2018"
TO_EMAILS = ["marimuthu@transforma.in"]
CC_EMAILS = ["dhamodaran@transforma.in", "siva@transforma.in"]  # Optional CC

# SMTP_SERVER = "smtp.office365.com"
# SMTP_PORT = 587
# SENDER_EMAIL = "siva@transforma.in"
# SENDER_PASSWORD = "tpl@8903369255"
# TO_EMAILS = ["siva@transforma.in"]
# CC_EMAILS = ["siva@transforma.in"]