@echo off
cd /d D:\Localserver\Apache\htdocs\workflow-new\python_ftp_download\tsp

echo Starting FTP Revises Final Download...
python revises_final_download.py

echo Sending email notification...
python mail_sent.py

echo All tasks completed successfully!
