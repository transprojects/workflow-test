<?php 
// Remove execution time limit
set_time_limit(0);
//include ('dbc.php'); 
include ('../includes/conn.php'); 

date_default_timezone_set('Asia/Kolkata');



	
/// Get Schedule mail details ////
$query = "SELECT * FROM `adm_schedule_mail_details` WHERE type = 'WIP_Schedule_mail_details' ";
$schedule_mail = $db->query($query) or ($db->error);
$schedule_details = $schedule_mail->fetch_assoc();
				
$mail_from = $schedule_details['from_email'];
$mail_pass = $schedule_details['from_email_pwd'];

$to_mails = $schedule_details['to_email'];
$cc_mails = $schedule_details['cc_email'];
$bcc_mails = $schedule_details['bcc_email'];

/* $mail_from = SCHEDULE_STATUS_FROM_MAIL;
$mail_pass = SCHEDULE_STATUS_FROM_MAIL_PASSWORD; */

// $to_mails = "swamy@transforma.in";
// $cc_mails = "";
// $bcc_mails = ""; 

	//// Get the article details ////
	$head = '<!DOCTYPE html>
<html>
<head>
<style>
table{
	width:80%;
}
#customers {
  font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

#customers td, #customers th {
  border: 1px solid #ddd;
  padding: 8px;
}

#customers tr:nth-child(even){background-color: #f2f2f2;}

#customers tr:hover {background-color: #ddd;}

#customers th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: #4CAF50;
  color: white;
}
#t_div{
 padding-top: 12px;
padding-bottom: 12px;
background-color: #4E9AEC;
color: white;
text-align: center;
font-weight: bold;
font-size: x-large;
}
.ct{
background-color:#f51f1f !important;
}
.eq{
background-color:#f5f538 !important;
}
.qr{
background-color:#98d7f0 !important;
}
.badge-info, .badge.badge-info, .label-info, .label.label-info {
    background-color: #3A87AD;
}
.label-sm {
    padding: .2em .4em .3em;
    font-size: 11px;
    line-height: 1;
    height: 18px;
}

.label {
    color: #FFF;
    display: inline-block;
}
.label.label-warning {
    background-color: #F89406;
}
</style>
</head>
<body>
';

$close = "</body>
</html>";

	$body ="" ;
	
	$today_date = date("Y-m-d");  /// today date
	

	//// First Proof Articles Details ////
	
	// $query = "SELECT inw.cust_id, inw.j_id, inw.due_dt, inw.recv_dt, inw.pub_id, inw.stage, inw.department_id FROM inw_inward_dtl as inw WHERE inw.status != 'Client Review' AND inw.created_dt > '2020-03-01' AND inw.stage='FP' AND inw.cust_id != 44 ORDER BY inw.cust_id, inw.j_id, inw.recv_dt, inw.due_dt ASC";
	$query = "SELECT inw.id, inw.cust_id, inw.j_id, inw.due_dt, inw.recv_dt, inw.pub_id, inw.stage, inw.status, inw.department_id, inw.page_count, inw.created_dt FROM inw_inward_dtl as inw WHERE inw.status != 'Client Review' AND inw.created_dt > '2020-03-01' AND inw.stage='FP' AND inw.cust_id != 44 AND inw.cust_id > 0 ORDER BY inw.cust_id,  inw.due_dt ASC";
	$articledetails = $db->query($query) or ($db->error);
	$filecount = 1;
	if($articledetails->num_rows > 0 )
	{
		$body .= '<div id="t_div">First Proof Articles</div>
		<table id="customers">
			<col width="5%">
			<col width="5%">
			<col width="5%">
			<col width="10%">
			<col width="10%">
			<col width="20%">
			<col width="15%">
			<col width="10%">
			<col width="5%">
			<col width="5%">
			<col width="5%">
			<col width="10%">';
			
			$body .= '<tr>
<td colspan="11">
<table style="border:1px #000000 solid;font-size: 14px;">
  <tbody>
  <tr style="color: #393939;font-weight: 600;background: repeat-x #F2F2F2;">
  <td>Customer</td>
  <td style="background-color: #090;color: white;">Dispatched</td>
  <td>Received</td>
  <td style="background-color: #06F;color: white;">WIP</td>
  <td style="background-color: #808080;color: white;">QH</td>
  <td style="background-color: #FF0000;color: white;">Overdue</td>
  <td style="background-color: #f0a150;color: white;">Today</td>
  <td style="background-color: #f09537;color: white;">>1day</td>
  <td style="background-color: #f48020;color: white;">>2day</td>
  <td style="background-color: #f0750f;color: white;">>3day</td>
  <td style="background-color: #c76706;color: white;">>4day</td>
  <td style="background-color: #3A87AD;color: white;">>allothers</td>
  </tr>';	
	$total_sent_count= 0;	
	$total_recv_count= 0;
	$total_wip_count= 0;
	$total_qh_count= 0;
	
	$total_overdue_count= 0;
	$total_today_count= 0;
	$total_one_day_count= 0;
	$total_two_day_count= 0;
	$total_three_day_count= 0;
	$total_four_day_count = 0;
	$total_allothers_count = 0;
		
	if(date('H') > 11)
	{
		$date_sent = date('Y-m-d')." 00:00:00";
		$date_recv = date('Y-m-d');
		$end_date = date('Y-m-d')." 23:59:59";
	}
	else
	{
		$date_sent = date('Y-m-d',strtotime("-1 days"))." 00:00:00";
		$date_recv = date('Y-m-d',strtotime("-1 days"));
		$end_date = date('Y-m-d',strtotime("-1 days"))." 23:59:59";
	}
	
	
    $sql_query = "SELECT * FROM `adm_customer_master` ORDER BY `cust_name` ASC";	
    $run_row = $db->query($sql_query) or die($db->error);	
    while ($row = $run_row->fetch_assoc()) 
	{		
        
		//Dispatched
		$cnt_query = "SELECT COUNT( DISTINCT dh.idh_id) as sent_count FROM inw_dispatch_history as dh, `inw_inward_dtl` as wd WHERE dh.a_id = wd.id AND wd.cust_id = ".$row['id']." AND dh.stage = 'FP' AND dh.sent_date BETWEEN '".$date_sent."' AND NOW();";
		$fp_run_query = $db->query($cnt_query) or die($db->error);
		$fp_row = $fp_run_query->fetch_assoc();
		$sent_count = $fp_row['sent_count'];
		$total_sent_count += $sent_count;
		
		//Received
		$fp_query = "SELECT COUNT( DISTINCT id)as recv_count FROM `inw_inward_dtl` WHERE cust_id =".$row['id']." AND stage = 'FP' AND recv_dt BETWEEN '".$date_recv."' AND NOW();";
		$fp_run_query = $db->query($fp_query) or die($db->error);
		$fp_row = $fp_run_query->fetch_assoc();
		$recv_count = $fp_row['recv_count'];
		$total_recv_count += $recv_count;
		
		//WIP
		$fp_query = "SELECT COUNT( DISTINCT id)as wip_count FROM `inw_inward_dtl` WHERE cust_id =".$row['id']." AND  stage = 'FP' AND status NOT IN ('Delivery','Client Review','Completed','Query','Hold');";
		$fp_run_query = $db->query($fp_query) or die($db->error);
		$fp_row = $fp_run_query->fetch_assoc();
		$wip_count = $fp_row['wip_count'];
		$total_wip_count += $wip_count;
		
		//Q&H
		$fp_query = "SELECT COUNT( DISTINCT id)as qh_count FROM `inw_inward_dtl` WHERE cust_id =".$row['id']." AND  stage = 'FP' AND status IN ('Query','Hold');";
		$fp_run_query = $db->query($fp_query) or die($db->error);
		$fp_row = $fp_run_query->fetch_assoc();
		$qh_count = $fp_row['qh_count'];
		$total_qh_count += $qh_count;	
		
		//Overdue
		$fp_query = "SELECT COUNT( DISTINCT id)as overdue_count FROM `inw_inward_dtl` WHERE cust_id =".$row['id']." AND  stage = 'FP' AND status NOT IN ('Delivery','Client Review','Completed','Query','Hold') AND `due_dt` < '".$end_date."';";
		$fp_run_query = $db->query($fp_query) or die($db->error);
		$fp_row = $fp_run_query->fetch_assoc();
		$overdue_count = $fp_row['overdue_count'];
		$total_overdue_count += $overdue_count;	
		
		//Today
		$fp_query = "SELECT COUNT( DISTINCT id)as today_count FROM `inw_inward_dtl` WHERE cust_id =".$row['id']." AND  stage = 'FP' AND status NOT IN ('Delivery','Client Review','Completed','Query','Hold') AND `due_dt` LIKE '".date('Y-m-d')."';";
		$fp_run_query = $db->query($fp_query) or die($db->error);
		$fp_row = $fp_run_query->fetch_assoc();
		$today_count = $fp_row['today_count'];
		$total_today_count += $today_count;
		
		//>1day
		$fp_query = "SELECT COUNT( DISTINCT id)as one_day_count FROM `inw_inward_dtl` WHERE cust_id =".$row['id']." AND  stage = 'FP' AND status NOT IN ('Delivery','Client Review','Completed','Query','Hold') AND `due_dt` LIKE '".date('Y-m-d',strtotime("+1 days"))."';";
		$fp_run_query = $db->query($fp_query) or die($db->error);
		$fp_row = $fp_run_query->fetch_assoc();
		$one_day_count = $fp_row['one_day_count'];
		$total_one_day_count += $one_day_count;	
		
		//>2day
		$fp_query = "SELECT COUNT( DISTINCT id)as two_day_count FROM `inw_inward_dtl` WHERE cust_id =".$row['id']." AND  stage = 'FP' AND status NOT IN ('Delivery','Client Review','Completed','Query','Hold') AND `due_dt` LIKE '".date('Y-m-d',strtotime("+2 days"))."';";
		$fp_run_query = $db->query($fp_query) or die($db->error);
		$fp_row = $fp_run_query->fetch_assoc();
		$two_day_count = $fp_row['two_day_count'];
		$total_two_day_count += $two_day_count;	
		
		//>3day
		$fp_query = "SELECT COUNT( DISTINCT id)as three_day_count FROM `inw_inward_dtl` WHERE cust_id =".$row['id']." AND  stage = 'FP' AND status NOT IN ('Delivery','Client Review','Completed','Query','Hold') AND `due_dt` LIKE '".date('Y-m-d',strtotime("+3 days"))."';";
		$fp_run_query = $db->query($fp_query) or die($db->error);
		$fp_row = $fp_run_query->fetch_assoc();
		$three_day_count = $fp_row['three_day_count'];
		$total_three_day_count += $three_day_count;	
		
		//>4day
		$fp_query = "SELECT COUNT( DISTINCT id)as four_day_count FROM `inw_inward_dtl` WHERE cust_id =".$row['id']." AND  stage = 'FP' AND status NOT IN ('Delivery','Client Review','Completed','Query','Hold') AND `due_dt` LIKE '".date('Y-m-d',strtotime("+4 days"))."';";
		$fp_run_query = $db->query($fp_query) or die($db->error);
		$fp_row = $fp_run_query->fetch_assoc();
		$four_day_count = $fp_row['four_day_count'];
		$total_four_day_count += $four_day_count;	
		
		//>allothers
		$fp_query = "SELECT COUNT( DISTINCT id)as allothers_count FROM `inw_inward_dtl` WHERE cust_id =".$row['id']." AND  stage = 'FP' AND status NOT IN ('Delivery','Client Review','Completed','Query','Hold') AND `due_dt` > '".date('Y-m-d',strtotime("+4 days"))."';";
		$fp_run_query = $db->query($fp_query) or die($db->error);
		$fp_row = $fp_run_query->fetch_assoc();
		$allothers_count = $fp_row['allothers_count'];
		$total_allothers_count += $allothers_count;				
			
		if($sent_count > 0 || $recv_count > 0 || $wip_count > 0)
		{
		$body .= '<tr><td>'.$row['cust_name'].'</td><td style="color: #090; text-align: right;">'.$sent_count.'</td><td style="color: #000; text-align: right;">'.$recv_count.'</td><td style="color: #06F; text-align: right;">'.$wip_count.'</td><td style="color: #808080; text-align: right;">'.$qh_count.'</td><td style="color: #FF0000; text-align: right;">'.$overdue_count.'</td><td style="color: #f0a150; text-align: right;">'.$today_count.'</td><td style="color: #f09537; text-align: right;">'.$one_day_count.'</td><td style="color: #f48020; text-align: right;">'.$two_day_count.'</td><td style="color: #f0750f; text-align: right;">'.$three_day_count.'</td><td style="color: #c76706; text-align: right;">'.$four_day_count.'</td><td style="color: #3A87AD; text-align: right;">'.$allothers_count.'</td></tr>';
		}
			
    }
		$body .= '<tr style="font-weight: 600; font-size:16px;"><td>TOTAL</td><td style="background-color: #090;color: white;text-align: right;">'.$total_sent_count.'</td><td style="background-color: #000;color: white;text-align: right;">'.$total_recv_count.'</td><td style="background-color: #06F;color: white;text-align: right;">'.$total_wip_count.'</td><td style="background-color: #808080;color: white;text-align: right;">'.$total_qh_count.'</td><td style="background-color: #FF0000;color: white;text-align: right;">'.$total_overdue_count.'</td><td style="background-color: #f0a150;color: white;text-align: right;">'.$total_today_count.'</td><td style="background-color: #f09537;color: white;text-align: right;">'.$total_one_day_count.'</td><td style="background-color: #f48020;color: white;text-align: right;">'.$total_two_day_count.'</td><td style="background-color: #f0750f;color: white;text-align: right;">'.$total_three_day_count.'</td><td style="background-color: #c76706;color: white;text-align: right;">'.$total_four_day_count.'</td><td style="background-color: #3A87AD;color: white;text-align: right;">'.$total_allothers_count.'</td></tr>';
	
	$body .= '</tbody>  
</table>
</td>
</tr></table>';

//// REV Articles Details ////
	
	$body .= '<div id="t_div">REV Articles</div>
		<table id="customers">
			<col width="5%">
			<col width="5%">
			<col width="5%">
			<col width="10%">
			<col width="10%">
			<col width="20%">
			<col width="15%">
			<col width="10%">
			<col width="5%">
			<col width="5%">
			<col width="5%">
			<col width="10%">';
			
			$body .= '<tr>
<td colspan="11">
<table style="border:1px #000000 solid;font-size: 14px;">
  <tbody>
  <tr style="color: #393939;font-weight: 600;background: repeat-x #F2F2F2;">
  <td>Customer</td>
  <td style="background-color: #090;color: white;">Dispatched</td>
  <td>Received</td>
  <td style="background-color: #06F;color: white;">WIP</td>
  <td style="background-color: #808080;color: white;">QH</td>
  <td style="background-color: #FF0000;color: white;">Overdue</td>
  <td style="background-color: #f0a150;color: white;">Today</td>
  <td style="background-color: #f09537;color: white;">>1day</td>
  <td style="background-color: #f48020;color: white;">>2day</td>
  <td style="background-color: #f0750f;color: white;">>3day</td>
  <td style="background-color: #c76706;color: white;">>4day</td>
  <td style="background-color: #3A87AD;color: white;">>allothers</td>
  </tr>';	
	$total_sent_count= 0;	
	$total_recv_count= 0;
	$total_wip_count= 0;
	$total_qh_count= 0;
	
	$total_overdue_count= 0;
	$total_today_count= 0;
	$total_one_day_count= 0;
	$total_two_day_count= 0;
	$total_three_day_count= 0;
	$total_four_day_count = 0;
	$total_allothers_count = 0;
		
	if(date('H') > 11)
	{
		$date_sent = date('Y-m-d')." 00:00:00";
		$date_recv = date('Y-m-d');
	}
	else
	{
		$date_sent = date('Y-m-d',strtotime("-1 days"))." 00:00:00";
		$date_recv = date('Y-m-d',strtotime("-1 days"));
	}
	
    $sql_query = "SELECT * FROM `adm_customer_master` ORDER BY `cust_name` ASC";	
    $run_row = $db->query($sql_query) or die($db->error);	
    while ($row = $run_row->fetch_assoc()) 
	{		
        
		//Dispatched
		$cnt_query = "SELECT COUNT( DISTINCT dh.idh_id) as sent_count FROM inw_dispatch_history as dh, `inw_inward_dtl` as wd WHERE dh.a_id = wd.id AND wd.cust_id = ".$row['id']." AND dh.stage LIKE 'REV%' AND dh.sent_date BETWEEN '".$date_sent."' AND NOW();";
		$fp_run_query = $db->query($cnt_query) or die($db->error);
		$fp_row = $fp_run_query->fetch_assoc();
		$sent_count = $fp_row['sent_count'];
		$total_sent_count += $sent_count;
		
		//Received
		$fp_query = "SELECT COUNT( DISTINCT wd.id)as recv_count FROM `inw_inward_dtl` as wd LEFT JOIN inw_revisions_dtl as r ON wd.id = r.inw_id WHERE wd.cust_id =".$row['id']." AND wd.stage LIKE 'REV%' AND r.received_date BETWEEN '".$date_recv."' AND NOW();";
		$fp_run_query = $db->query($fp_query) or die($db->error);
		$fp_row = $fp_run_query->fetch_assoc();
		$recv_count = $fp_row['recv_count'];
		$total_recv_count += $recv_count;
		
		//WIP
		$fp_query = "SELECT COUNT( DISTINCT wd.id)as wip_count FROM `inw_inward_dtl` as wd WHERE wd.cust_id =".$row['id']." AND wd.stage LIKE 'REV%' AND wd.status NOT IN ('Delivery','Client Review','Completed','Query','Hold');";
		$fp_run_query = $db->query($fp_query) or die($db->error);
		$fp_row = $fp_run_query->fetch_assoc();
		$wip_count = $fp_row['wip_count'];
		$total_wip_count += $wip_count;
		
		//Q&H
		$fp_query = "SELECT COUNT( DISTINCT wd.id)as qh_count FROM `inw_inward_dtl` as wd WHERE wd.cust_id =".$row['id']." AND wd.stage LIKE 'REV%' AND wd.status IN ('Query','Hold');";
		$fp_run_query = $db->query($fp_query) or die($db->error);
		$fp_row = $fp_run_query->fetch_assoc();
		$qh_count = $fp_row['qh_count'];
		$total_qh_count += $qh_count;	
		
		//Overdue
		$fp_query = "SELECT COUNT( DISTINCT wd.id)as overdue_count
FROM `inw_inward_dtl` AS wd 
LEFT JOIN inw_revisions_dtl AS r ON wd.id = r.inw_id 
WHERE wd.cust_id = ".$row['id']." 
      AND wd.stage LIKE 'REV%' 
      AND wd.status NOT IN ('Delivery', 'Client Review', 'Completed', 'Query', 'Hold') 
      AND (SELECT MAX(r_inner.r_id) 
           FROM inw_revisions_dtl AS r_inner 
           WHERE r_inner.inw_id = wd.id) = r.r_id 
       AND r.due_date < '".$end_date."';";
		$fp_run_query = $db->query($fp_query) or die($db->error);
		$fp_row = $fp_run_query->fetch_assoc();
		$overdue_count = $fp_row['overdue_count'];
		$total_overdue_count += $overdue_count;	
		
		//Today
		$fp_query = "SELECT COUNT( DISTINCT wd.id)as today_count FROM `inw_inward_dtl` as wd LEFT JOIN inw_revisions_dtl as r ON wd.id = r.inw_id WHERE wd.cust_id =".$row['id']." AND wd.stage LIKE 'REV%' AND wd.status NOT IN ('Delivery','Client Review','Completed','Query','Hold') AND r.`due_date` LIKE '".date('Y-m-d')."';";
		$fp_run_query = $db->query($fp_query) or die($db->error);
		$fp_row = $fp_run_query->fetch_assoc();
		$today_count = $fp_row['today_count'];
		$total_today_count += $today_count;
		
		//>1day
		$fp_query = "SELECT COUNT( DISTINCT wd.id)as one_day_count FROM `inw_inward_dtl` as wd LEFT JOIN inw_revisions_dtl as r ON wd.id = r.inw_id WHERE wd.cust_id =".$row['id']." AND wd.stage LIKE 'REV%' AND wd.status NOT IN ('Delivery','Client Review','Completed','Query','Hold') AND r.`due_date` LIKE '".date('Y-m-d',strtotime("+1 days"))."';";
		$fp_run_query = $db->query($fp_query) or die($db->error);
		$fp_row = $fp_run_query->fetch_assoc();
		$one_day_count = $fp_row['one_day_count'];
		$total_one_day_count += $one_day_count;	
		
		//>2day
		$fp_query = "SELECT COUNT( DISTINCT wd.id)as two_day_count FROM `inw_inward_dtl` as wd LEFT JOIN inw_revisions_dtl as r ON wd.id = r.inw_id WHERE wd.cust_id =".$row['id']." AND wd.stage LIKE 'REV%' AND wd.status NOT IN ('Delivery','Client Review','Completed','Query','Hold') AND r.`due_date` LIKE '".date('Y-m-d',strtotime("+2 days"))."';";
		$fp_run_query = $db->query($fp_query) or die($db->error);
		$fp_row = $fp_run_query->fetch_assoc();
		$two_day_count = $fp_row['two_day_count'];
		$total_two_day_count += $two_day_count;	
		
		//>3day
		$fp_query = "SELECT COUNT( DISTINCT wd.id)as three_day_count FROM `inw_inward_dtl` as wd LEFT JOIN inw_revisions_dtl as r ON wd.id = r.inw_id WHERE wd.cust_id =".$row['id']." AND wd.stage LIKE 'REV%' AND wd.status NOT IN ('Delivery','Client Review','Completed','Query','Hold') AND r.`due_date` LIKE '".date('Y-m-d',strtotime("+3 days"))."';";
		$fp_run_query = $db->query($fp_query) or die($db->error);
		$fp_row = $fp_run_query->fetch_assoc();
		$three_day_count = $fp_row['three_day_count'];
		$total_three_day_count += $three_day_count;	
		
		//>4day
		$fp_query = "SELECT COUNT( DISTINCT wd.id)as four_day_count FROM `inw_inward_dtl` as wd LEFT JOIN inw_revisions_dtl as r ON wd.id = r.inw_id WHERE wd.cust_id =".$row['id']." AND wd.stage LIKE 'REV%' AND wd.status NOT IN ('Delivery','Client Review','Completed','Query','Hold') AND r.`due_date` LIKE '".date('Y-m-d',strtotime("+4 days"))."';";
		$fp_run_query = $db->query($fp_query) or die($db->error);
		$fp_row = $fp_run_query->fetch_assoc();
		$four_day_count = $fp_row['four_day_count'];
		$total_four_day_count += $four_day_count;	
		
		//>allothers
		$fp_query = "SELECT COUNT( DISTINCT wd.id)as allothers_count FROM `inw_inward_dtl` as wd LEFT JOIN inw_revisions_dtl as r ON wd.id = r.inw_id WHERE wd.cust_id =".$row['id']." AND wd.stage LIKE 'REV%' AND wd.status NOT IN ('Delivery','Client Review','Completed','Query','Hold') AND r.`due_date` > '".date('Y-m-d',strtotime("+4 days"))."';";
		$fp_run_query = $db->query($fp_query) or die($db->error);
		$fp_row = $fp_run_query->fetch_assoc();
		$allothers_count = $fp_row['allothers_count'];
		$total_allothers_count += $allothers_count;				
			
		if($sent_count > 0 || $recv_count > 0 || $wip_count > 0)
		{
		$body .= '<tr><td>'.$row['cust_name'].'</td><td style="color: #090; text-align: right;">'.$sent_count.'</td><td style="color: #000; text-align: right;">'.$recv_count.'</td><td style="color: #06F; text-align: right;">'.$wip_count.'</td><td style="color: #808080; text-align: right;">'.$qh_count.'</td><td style="color: #FF0000; text-align: right;">'.$overdue_count.'</td><td style="color: #f0a150; text-align: right;">'.$today_count.'</td><td style="color: #f09537; text-align: right;">'.$one_day_count.'</td><td style="color: #f48020; text-align: right;">'.$two_day_count.'</td><td style="color: #f0750f; text-align: right;">'.$three_day_count.'</td><td style="color: #c76706; text-align: right;">'.$four_day_count.'</td><td style="color: #3A87AD; text-align: right;">'.$allothers_count.'</td></tr>';
		}
			
    }
		$body .= '<tr style="font-weight: 600; font-size:16px;"><td>TOTAL</td><td style="background-color: #090;color: white;text-align: right;">'.$total_sent_count.'</td><td style="background-color: #000;color: white;text-align: right;">'.$total_recv_count.'</td><td style="background-color: #06F;color: white;text-align: right;">'.$total_wip_count.'</td><td style="background-color: #808080;color: white;text-align: right;">'.$total_qh_count.'</td><td style="background-color: #FF0000;color: white;text-align: right;">'.$total_overdue_count.'</td><td style="background-color: #f0a150;color: white;text-align: right;">'.$total_today_count.'</td><td style="background-color: #f09537;color: white;text-align: right;">'.$total_one_day_count.'</td><td style="background-color: #f48020;color: white;text-align: right;">'.$total_two_day_count.'</td><td style="background-color: #f0750f;color: white;text-align: right;">'.$total_three_day_count.'</td><td style="background-color: #c76706;color: white;text-align: right;">'.$total_four_day_count.'</td><td style="background-color: #3A87AD;color: white;text-align: right;">'.$total_allothers_count.'</td></tr>';
	
	$body .= '</tbody>  
</table>
</td>
</tr></table>';


//// PMC Articles Details ////
	
	$body .= '<div id="t_div">PMC Articles</div>
		<table id="customers">
			<col width="5%">
			<col width="5%">
			<col width="5%">
			<col width="10%">
			<col width="10%">
			<col width="20%">
			<col width="15%">
			<col width="10%">
			<col width="5%">
			<col width="5%">
			<col width="5%">
			<col width="10%">';
			
			$body .= '<tr>
<td colspan="11">
<table style="border:1px #000000 solid;font-size: 14px;">
  <tbody>
  <tr style="color: #393939;font-weight: 600;background: repeat-x #F2F2F2;">
  <td>Customer</td>
  <td style="background-color: #090;color: white;">Dispatched</td>
  <td>Received</td>
  <td style="background-color: #06F;color: white;">WIP</td>
  <td style="background-color: #808080;color: white;">QH</td>
  <td style="background-color: #FF0000;color: white;">Overdue</td>
  <td style="background-color: #f0a150;color: white;">Today</td>
  <td style="background-color: #f09537;color: white;">>1day</td>
  <td style="background-color: #f48020;color: white;">>2day</td>
  <td style="background-color: #f0750f;color: white;">>3day</td>
  <td style="background-color: #c76706;color: white;">>4day</td>
  <td style="background-color: #3A87AD;color: white;">>allothers</td>
  </tr>';	
	$total_sent_count= 0;	
	$total_recv_count= 0;
	$total_wip_count= 0;
	$total_qh_count= 0;
	
	$total_overdue_count= 0;
	$total_today_count= 0;
	$total_one_day_count= 0;
	$total_two_day_count= 0;
	$total_three_day_count= 0;
	$total_four_day_count = 0;
	$total_allothers_count = 0;
		
	if(date('H') > 11)
	{
		$date_sent = date('Y-m-d')." 00:00:00";
		$date_recv = date('Y-m-d');
	}
	else
	{
		$date_sent = date('Y-m-d',strtotime("-1 days"))." 00:00:00";
		$date_recv = date('Y-m-d',strtotime("-1 days"));
	}
	
    $sql_query = "SELECT * FROM `adm_customer_master` ORDER BY `cust_name` ASC";	
    $run_row = $db->query($sql_query) or die($db->error);	
    while ($row = $run_row->fetch_assoc()) 
	{		
        
		//Dispatched
		$cnt_query = "SELECT COUNT( DISTINCT dh.idh_id) as sent_count FROM inw_dispatch_history as dh, `inw_inward_dtl` as wd WHERE dh.a_id = wd.id AND wd.cust_id = ".$row['id']." AND dh.stage LIKE 'PMC%' AND dh.sent_date BETWEEN '".$date_sent."' AND NOW();";
		$fp_run_query = $db->query($cnt_query) or die($db->error);
		$fp_row = $fp_run_query->fetch_assoc();
		$sent_count = $fp_row['sent_count'];
		$total_sent_count += $sent_count;
		
		//Received
		$fp_query = "SELECT COUNT( DISTINCT wd.id)as recv_count FROM `inw_inward_dtl` as wd LEFT JOIN inw_revisions_dtl as r ON wd.id = r.inw_id WHERE wd.cust_id =".$row['id']." AND wd.stage LIKE 'PMC%' AND r.received_date BETWEEN '".$date_recv."' AND NOW();";
		$fp_run_query = $db->query($fp_query) or die($db->error);
		$fp_row = $fp_run_query->fetch_assoc();
		$recv_count = $fp_row['recv_count'];
		$total_recv_count += $recv_count;
		
		//WIP
		$fp_query = "SELECT COUNT( DISTINCT wd.id)as wip_count FROM `inw_inward_dtl` as wd WHERE wd.cust_id =".$row['id']." AND wd.stage LIKE 'PMC%' AND wd.status NOT IN ('Delivery','Client Review','Completed','Query','Hold');";
		$fp_run_query = $db->query($fp_query) or die($db->error);
		$fp_row = $fp_run_query->fetch_assoc();
		$wip_count = $fp_row['wip_count'];
		$total_wip_count += $wip_count;
		
		//Q&H
		$fp_query = "SELECT COUNT( DISTINCT wd.id)as qh_count FROM `inw_inward_dtl` as wd WHERE wd.cust_id =".$row['id']." AND wd.stage LIKE 'PMC%' AND wd.status IN ('Query','Hold');";
		$fp_run_query = $db->query($fp_query) or die($db->error);
		$fp_row = $fp_run_query->fetch_assoc();
		$qh_count = $fp_row['qh_count'];
		$total_qh_count += $qh_count;	
		
		//Overdue
		$fp_query = "SELECT COUNT( DISTINCT wd.id)as overdue_count
FROM `inw_inward_dtl` AS wd 
LEFT JOIN inw_revisions_dtl AS r ON wd.id = r.inw_id 
WHERE wd.cust_id = ".$row['id']." 
      AND wd.stage LIKE 'PMC%' 
      AND wd.status NOT IN ('Delivery', 'Client Review', 'Completed', 'Query', 'Hold') 
      AND (SELECT MAX(r_inner.r_id) 
           FROM inw_revisions_dtl AS r_inner 
           WHERE r_inner.inw_id = wd.id) = r.r_id 
       AND r.due_date < '".$end_date."';";
		$fp_run_query = $db->query($fp_query) or die($db->error);
		$fp_row = $fp_run_query->fetch_assoc();
		$overdue_count = $fp_row['overdue_count'];
		$total_overdue_count += $overdue_count;	
		
		//Today
		$fp_query = "SELECT COUNT( DISTINCT wd.id)as today_count FROM `inw_inward_dtl` as wd LEFT JOIN inw_revisions_dtl as r ON wd.id = r.inw_id WHERE wd.cust_id =".$row['id']." AND wd.stage LIKE 'PMC%' AND wd.status NOT IN ('Delivery','Client Review','Completed','Query','Hold') AND r.`due_date` LIKE '".date('Y-m-d')."';";
		$fp_run_query = $db->query($fp_query) or die($db->error);
		$fp_row = $fp_run_query->fetch_assoc();
		$today_count = $fp_row['today_count'];
		$total_today_count += $today_count;
		
		//>1day
		$fp_query = "SELECT COUNT( DISTINCT wd.id)as one_day_count FROM `inw_inward_dtl` as wd LEFT JOIN inw_revisions_dtl as r ON wd.id = r.inw_id WHERE wd.cust_id =".$row['id']." AND wd.stage LIKE 'PMC%' AND wd.status NOT IN ('Delivery','Client Review','Completed','Query','Hold') AND r.`due_date` LIKE '".date('Y-m-d',strtotime("+1 days"))."';";
		$fp_run_query = $db->query($fp_query) or die($db->error);
		$fp_row = $fp_run_query->fetch_assoc();
		$one_day_count = $fp_row['one_day_count'];
		$total_one_day_count += $one_day_count;	
		
		//>2day
		$fp_query = "SELECT COUNT( DISTINCT wd.id)as two_day_count FROM `inw_inward_dtl` as wd LEFT JOIN inw_revisions_dtl as r ON wd.id = r.inw_id WHERE wd.cust_id =".$row['id']." AND wd.stage LIKE 'PMC%' AND wd.status NOT IN ('Delivery','Client Review','Completed','Query','Hold') AND r.`due_date` LIKE '".date('Y-m-d',strtotime("+2 days"))."';";
		$fp_run_query = $db->query($fp_query) or die($db->error);
		$fp_row = $fp_run_query->fetch_assoc();
		$two_day_count = $fp_row['two_day_count'];
		$total_two_day_count += $two_day_count;	
		
		//>3day
		$fp_query = "SELECT COUNT( DISTINCT wd.id)as three_day_count FROM `inw_inward_dtl` as wd LEFT JOIN inw_revisions_dtl as r ON wd.id = r.inw_id WHERE wd.cust_id =".$row['id']." AND wd.stage LIKE 'PMC%' AND wd.status NOT IN ('Delivery','Client Review','Completed','Query','Hold') AND r.`due_date` LIKE '".date('Y-m-d',strtotime("+3 days"))."';";
		$fp_run_query = $db->query($fp_query) or die($db->error);
		$fp_row = $fp_run_query->fetch_assoc();
		$three_day_count = $fp_row['three_day_count'];
		$total_three_day_count += $three_day_count;	
		
		//>4day
		$fp_query = "SELECT COUNT( DISTINCT wd.id)as four_day_count FROM `inw_inward_dtl` as wd LEFT JOIN inw_revisions_dtl as r ON wd.id = r.inw_id WHERE wd.cust_id =".$row['id']." AND wd.stage LIKE 'PMC%' AND wd.status NOT IN ('Delivery','Client Review','Completed','Query','Hold') AND r.`due_date` LIKE '".date('Y-m-d',strtotime("+4 days"))."';";
		$fp_run_query = $db->query($fp_query) or die($db->error);
		$fp_row = $fp_run_query->fetch_assoc();
		$four_day_count = $fp_row['four_day_count'];
		$total_four_day_count += $four_day_count;	
		
		//>allothers
		$fp_query = "SELECT COUNT( DISTINCT wd.id)as allothers_count FROM `inw_inward_dtl` as wd LEFT JOIN inw_revisions_dtl as r ON wd.id = r.inw_id WHERE wd.cust_id =".$row['id']." AND wd.stage LIKE 'PMC%' AND wd.status NOT IN ('Delivery','Client Review','Completed','Query','Hold') AND r.`due_date` > '".date('Y-m-d',strtotime("+4 days"))."';";
		$fp_run_query = $db->query($fp_query) or die($db->error);
		$fp_row = $fp_run_query->fetch_assoc();
		$allothers_count = $fp_row['allothers_count'];
		$total_allothers_count += $allothers_count;				
			
		if($sent_count > 0 || $recv_count > 0 || $wip_count > 0)
		{
		$body .= '<tr><td>'.$row['cust_name'].'</td><td style="color: #090; text-align: right;">'.$sent_count.'</td><td style="color: #000; text-align: right;">'.$recv_count.'</td><td style="color: #06F; text-align: right;">'.$wip_count.'</td><td style="color: #808080; text-align: right;">'.$qh_count.'</td><td style="color: #FF0000; text-align: right;">'.$overdue_count.'</td><td style="color: #f0a150; text-align: right;">'.$today_count.'</td><td style="color: #f09537; text-align: right;">'.$one_day_count.'</td><td style="color: #f48020; text-align: right;">'.$two_day_count.'</td><td style="color: #f0750f; text-align: right;">'.$three_day_count.'</td><td style="color: #c76706; text-align: right;">'.$four_day_count.'</td><td style="color: #3A87AD; text-align: right;">'.$allothers_count.'</td></tr>';
		}
			
    }
		$body .= '<tr style="font-weight: 600; font-size:16px;"><td>TOTAL</td><td style="background-color: #090;color: white;text-align: right;">'.$total_sent_count.'</td><td style="background-color: #000;color: white;text-align: right;">'.$total_recv_count.'</td><td style="background-color: #06F;color: white;text-align: right;">'.$total_wip_count.'</td><td style="background-color: #808080;color: white;text-align: right;">'.$total_qh_count.'</td><td style="background-color: #FF0000;color: white;text-align: right;">'.$total_overdue_count.'</td><td style="background-color: #f0a150;color: white;text-align: right;">'.$total_today_count.'</td><td style="background-color: #f09537;color: white;text-align: right;">'.$total_one_day_count.'</td><td style="background-color: #f48020;color: white;text-align: right;">'.$total_two_day_count.'</td><td style="background-color: #f0750f;color: white;text-align: right;">'.$total_three_day_count.'</td><td style="background-color: #c76706;color: white;text-align: right;">'.$total_four_day_count.'</td><td style="background-color: #3A87AD;color: white;text-align: right;">'.$total_allothers_count.'</td></tr>';
	
	$body .= '</tbody>  
</table>
</td>
</tr></table>';


//// FIN Articles Details Start Here ////
	
	$body .= '<div id="t_div">FIN Articles</div>
		<table id="customers">
			<col width="5%">
			<col width="5%">
			<col width="5%">
			<col width="10%">
			<col width="10%">
			<col width="20%">
			<col width="15%">
			<col width="10%">
			<col width="5%">
			<col width="5%">
			<col width="5%">
			<col width="10%">';
			
			$body .= '<tr>
<td colspan="11">
<table style="border:1px #000000 solid;font-size: 14px;">
  <tbody>
  <tr style="color: #393939;font-weight: 600;background: repeat-x #F2F2F2;">
  <td>Customer</td>
  <td style="background-color: #090;color: white;">Dispatched</td>
  <td>Received</td>
  <td style="background-color: #06F;color: white;">WIP</td>
  <td style="background-color: #808080;color: white;">QH</td>
  <td style="background-color: #FF0000;color: white;">Overdue</td>
  <td style="background-color: #f0a150;color: white;">Today</td>
  <td style="background-color: #f09537;color: white;">>1day</td>
  <td style="background-color: #f48020;color: white;">>2day</td>
  <td style="background-color: #f0750f;color: white;">>3day</td>
  <td style="background-color: #c76706;color: white;">>4day</td>
  <td style="background-color: #3A87AD;color: white;">>allothers</td>
  </tr>';	
	$total_sent_count= 0;	
	$total_recv_count= 0;
	$total_wip_count= 0;
	$total_qh_count= 0;
	
	$total_overdue_count= 0;
	$total_today_count= 0;
	$total_one_day_count= 0;
	$total_two_day_count= 0;
	$total_three_day_count= 0;
	$total_four_day_count = 0;
	$total_allothers_count = 0;
		
	if(date('H') > 11)
	{
		$date_sent = date('Y-m-d')." 00:00:00";
		$date_recv = date('Y-m-d');
	}
	else
	{
		$date_sent = date('Y-m-d',strtotime("-1 days"))." 00:00:00";
		$date_recv = date('Y-m-d',strtotime("-1 days"));
	}
	
    $sql_query = "SELECT * FROM `adm_customer_master` ORDER BY `cust_name` ASC";	
    $run_row = $db->query($sql_query) or die($db->error);	
    while ($row = $run_row->fetch_assoc()) 
	{		
        
		//Dispatched
		$cnt_query = "SELECT COUNT( DISTINCT dh.idh_id) as sent_count FROM inw_dispatch_history as dh, `inw_inward_dtl` as wd WHERE dh.a_id = wd.id AND wd.cust_id = ".$row['id']." AND dh.stage LIKE 'FIN%' AND dh.sent_date BETWEEN '".$date_sent."' AND NOW();";
		$fp_run_query = $db->query($cnt_query) or die($db->error);
		$fp_row = $fp_run_query->fetch_assoc();
		$sent_count = $fp_row['sent_count'];
		$total_sent_count += $sent_count;
		
		//Received
		$fp_query = "SELECT COUNT( DISTINCT wd.id)as recv_count FROM `inw_inward_dtl` as wd LEFT JOIN inw_revisions_dtl as r ON wd.id = r.inw_id WHERE wd.cust_id =".$row['id']." AND wd.stage LIKE 'FIN%' AND r.received_date BETWEEN '".$date_recv."' AND NOW();";
		$fp_run_query = $db->query($fp_query) or die($db->error);
		$fp_row = $fp_run_query->fetch_assoc();
		$recv_count = $fp_row['recv_count'];
		$total_recv_count += $recv_count;
		
		//WIP
		$fp_query = "SELECT COUNT( DISTINCT wd.id)as wip_count FROM `inw_inward_dtl` as wd WHERE wd.cust_id =".$row['id']." AND wd.stage LIKE 'FIN%' AND wd.status NOT IN ('Delivery','Client Review','Completed','Query','Hold');";
		$fp_run_query = $db->query($fp_query) or die($db->error);
		$fp_row = $fp_run_query->fetch_assoc();
		$wip_count = $fp_row['wip_count'];
		$total_wip_count += $wip_count;
		
		//Q&H
		$fp_query = "SELECT COUNT( DISTINCT wd.id)as qh_count FROM `inw_inward_dtl` as wd WHERE wd.cust_id =".$row['id']." AND wd.stage LIKE 'FIN%' AND wd.status IN ('Query','Hold');";
		$fp_run_query = $db->query($fp_query) or die($db->error);
		$fp_row = $fp_run_query->fetch_assoc();
		$qh_count = $fp_row['qh_count'];
		$total_qh_count += $qh_count;	
		
		//Overdue
		//$fp_query = "SELECT COUNT( DISTINCT wd.id)as overdue_count FROM `inw_inward_dtl` as wd LEFT JOIN inw_revisions_dtl as r ON wd.id = r.inw_id WHERE wd.cust_id =".$row['id']." AND wd.stage LIKE 'FIN%' AND wd.status NOT IN ('Delivery','Client Review','Completed','Query','Hold') AND r.`due_date` < '".$end_date."';";
		
		$fp_query = "SELECT COUNT( DISTINCT wd.id)as overdue_count
FROM `inw_inward_dtl` AS wd 
LEFT JOIN inw_revisions_dtl AS r ON wd.id = r.inw_id 
WHERE wd.cust_id = ".$row['id']." 
      AND wd.stage LIKE 'FIN%' 
      AND wd.status NOT IN ('Delivery', 'Client Review', 'Completed', 'Query', 'Hold') 
      AND (SELECT MAX(r_inner.r_id) 
           FROM inw_revisions_dtl AS r_inner 
           WHERE r_inner.inw_id = wd.id) = r.r_id 
       AND r.due_date < '".$end_date."';";
	   
		
		$fp_run_query = $db->query($fp_query) or die($db->error);
		$fp_row = $fp_run_query->fetch_assoc();
		$overdue_count = $fp_row['overdue_count'];
		$total_overdue_count += $overdue_count;	
		
		//Today
		$fp_query = "SELECT COUNT( DISTINCT wd.id)as today_count FROM `inw_inward_dtl` as wd LEFT JOIN inw_revisions_dtl as r ON wd.id = r.inw_id WHERE wd.cust_id =".$row['id']." AND wd.stage LIKE 'FIN%' AND wd.status NOT IN ('Delivery','Client Review','Completed','Query','Hold') AND r.`due_date` LIKE '".date('Y-m-d')."';";
		$fp_run_query = $db->query($fp_query) or die($db->error);
		$fp_row = $fp_run_query->fetch_assoc();
		$today_count = $fp_row['today_count'];
		$total_today_count += $today_count;
		
		//>1day
		$fp_query = "SELECT COUNT( DISTINCT wd.id)as one_day_count FROM `inw_inward_dtl` as wd LEFT JOIN inw_revisions_dtl as r ON wd.id = r.inw_id WHERE wd.cust_id =".$row['id']." AND wd.stage LIKE 'FIN%' AND wd.status NOT IN ('Delivery','Client Review','Completed','Query','Hold') AND r.`due_date` LIKE '".date('Y-m-d',strtotime("+1 days"))."';";
		$fp_run_query = $db->query($fp_query) or die($db->error);
		$fp_row = $fp_run_query->fetch_assoc();
		$one_day_count = $fp_row['one_day_count'];
		$total_one_day_count += $one_day_count;	
		
		//>2day
		$fp_query = "SELECT COUNT( DISTINCT wd.id)as two_day_count FROM `inw_inward_dtl` as wd LEFT JOIN inw_revisions_dtl as r ON wd.id = r.inw_id WHERE wd.cust_id =".$row['id']." AND wd.stage LIKE 'FIN%' AND wd.status NOT IN ('Delivery','Client Review','Completed','Query','Hold') AND r.`due_date` LIKE '".date('Y-m-d',strtotime("+2 days"))."';";
		$fp_run_query = $db->query($fp_query) or die($db->error);
		$fp_row = $fp_run_query->fetch_assoc();
		$two_day_count = $fp_row['two_day_count'];
		$total_two_day_count += $two_day_count;	
		
		//>3day
		$fp_query = "SELECT COUNT( DISTINCT wd.id)as three_day_count FROM `inw_inward_dtl` as wd LEFT JOIN inw_revisions_dtl as r ON wd.id = r.inw_id WHERE wd.cust_id =".$row['id']." AND wd.stage LIKE 'FIN%' AND wd.status NOT IN ('Delivery','Client Review','Completed','Query','Hold') AND r.`due_date` LIKE '".date('Y-m-d',strtotime("+3 days"))."';";
		$fp_run_query = $db->query($fp_query) or die($db->error);
		$fp_row = $fp_run_query->fetch_assoc();
		$three_day_count = $fp_row['three_day_count'];
		$total_three_day_count += $three_day_count;	
		
		//>4day
		$fp_query = "SELECT COUNT( DISTINCT wd.id)as four_day_count FROM `inw_inward_dtl` as wd LEFT JOIN inw_revisions_dtl as r ON wd.id = r.inw_id WHERE wd.cust_id =".$row['id']." AND wd.stage LIKE 'FIN%' AND wd.status NOT IN ('Delivery','Client Review','Completed','Query','Hold') AND r.`due_date` LIKE '".date('Y-m-d',strtotime("+4 days"))."';";
		$fp_run_query = $db->query($fp_query) or die($db->error);
		$fp_row = $fp_run_query->fetch_assoc();
		$four_day_count = $fp_row['four_day_count'];
		$total_four_day_count += $four_day_count;	
		
		//>allothers
		$fp_query = "SELECT COUNT( DISTINCT wd.id)as allothers_count FROM `inw_inward_dtl` as wd LEFT JOIN inw_revisions_dtl as r ON wd.id = r.inw_id WHERE wd.cust_id =".$row['id']." AND wd.stage LIKE 'FIN%' AND wd.status NOT IN ('Delivery','Client Review','Completed','Query','Hold') AND r.`due_date` > '".date('Y-m-d',strtotime("+4 days"))."';";
		$fp_run_query = $db->query($fp_query) or die($db->error);
		$fp_row = $fp_run_query->fetch_assoc();
		$allothers_count = $fp_row['allothers_count'];
		$total_allothers_count += $allothers_count;				
			
		if($sent_count > 0 || $recv_count > 0 || $wip_count > 0)
		{
		$body .= '<tr><td>'.$row['cust_name'].'</td><td style="color: #090; text-align: right;">'.$sent_count.'</td><td style="color: #000; text-align: right;">'.$recv_count.'</td><td style="color: #06F; text-align: right;">'.$wip_count.'</td><td style="color: #808080; text-align: right;">'.$qh_count.'</td><td style="color: #FF0000; text-align: right;">'.$overdue_count.'</td><td style="color: #f0a150; text-align: right;">'.$today_count.'</td><td style="color: #f09537; text-align: right;">'.$one_day_count.'</td><td style="color: #f48020; text-align: right;">'.$two_day_count.'</td><td style="color: #f0750f; text-align: right;">'.$three_day_count.'</td><td style="color: #c76706; text-align: right;">'.$four_day_count.'</td><td style="color: #3A87AD; text-align: right;">'.$allothers_count.'</td></tr>';
		}
			
    }
		$body .= '<tr style="font-weight: 600; font-size:16px;"><td>TOTAL</td><td style="background-color: #090;color: white;text-align: right;">'.$total_sent_count.'</td><td style="background-color: #000;color: white;text-align: right;">'.$total_recv_count.'</td><td style="background-color: #06F;color: white;text-align: right;">'.$total_wip_count.'</td><td style="background-color: #808080;color: white;text-align: right;">'.$total_qh_count.'</td><td style="background-color: #FF0000;color: white;text-align: right;">'.$total_overdue_count.'</td><td style="background-color: #f0a150;color: white;text-align: right;">'.$total_today_count.'</td><td style="background-color: #f09537;color: white;text-align: right;">'.$total_one_day_count.'</td><td style="background-color: #f48020;color: white;text-align: right;">'.$total_two_day_count.'</td><td style="background-color: #f0750f;color: white;text-align: right;">'.$total_three_day_count.'</td><td style="background-color: #c76706;color: white;text-align: right;">'.$total_four_day_count.'</td><td style="background-color: #3A87AD;color: white;text-align: right;">'.$total_allothers_count.'</td></tr>';
	
	$body .= '</tbody>  
</table>
</td>
</tr>';

//////////////// FIN Articles End Here ////////////////

			
			
 
			$body .= '<tr>
				<th>S.No</th>
				<th>Customer S.NO</th>
				<th>Customer</th>
				<th>Journal</th>
				<th>Article Id</th>
				<th>Received Date</th>
				<th>Due Date</th>
				<th>Stage</th>
				<th>Department</th>
				<th>Query</th>
				<th>Manuscript Count</th>
			</tr>
		';
		$Customer_sn = 0;
		$Customer_id = "";
		   while ($article_info = $articledetails->fetch_assoc()) 
		   {
				if($Customer_id == "")
				{
					$Customer_id = $article_info['cust_id'];
					$Customer_sn++;
				}
				else if($Customer_id == $article_info['cust_id'])
				{
					$Customer_sn++;
				}
				else if($Customer_id != $article_info['cust_id'])
				{
					$Customer_id = $article_info['cust_id'];
					$Customer_sn = 1;
				}
				
			   	/// Get the customers details ////
				$query = "SELECT cust_name,cust_id,id,email,password FROM `adm_customer_master` WHERE id = '".$article_info['cust_id']."' ";
				$customers = $db->query($query) or ($db->error);
				$crow = $customers->fetch_assoc();
				
				
				//// Get the Journal Details ///	
				$query = "SELECT j_name,j_code FROM `adm_journals` WHERE j_id = '".$article_info['j_id']."';";
				$steps = $db->query($query) or ($db->error);
				$jninfo = $steps->fetch_assoc();
				
				/////// Get the department name /////
				$query = "SELECT * FROM adm_dept_master WHERE dept_code = '".$article_info['department_id']."'";
				$dpts = $db->query($query) or ($db->error);
				$dptinfo = $dpts->fetch_assoc();
		
				/// Get the process user name ////
				$trans_sql = "SELECT u.full_name,t.current_status,t.id FROM `inw_transactions` as t,users as u WHERE t.process_user = u.id AND t.`project_id` = '".$article_info['id']."'  AND t.current_status NOT IN ('Completed','Take Over') AND t.stage = '".$article_info['stage']."' AND ('Completed' != (select current_status from `inw_transactions` where `project_id` = '".$article_info['id']."' ORDER BY `id` DESC limit 1) )  ORDER BY t.`id` DESC limit 1;";
				
				$chk_transaction = $db->query($trans_sql); 
				$transaction_toatl_count=$chk_transaction->num_rows;
				$trans_res = $chk_transaction->fetch_assoc();
		
				$date_now = date("Y-m-d"); // this format is string comparable
				$due_dt = date('Y-m-d', strtotime($article_info['due_dt']));
				$due_dt_type = "";
				if ($date_now > $due_dt) {
					$due_dt_type="ct";
				}
				else if ($date_now < $due_dt) {
				$due_dt_type="lt";
				}
				else if ($date_now == $due_dt) {
					$due_dt_type="eq";
				}
				
				$query_status = "";
				if((strpos($article_info['status'], "Query") !== false) || (strpos($article_info['status'], "Hold") !== false))
				{
					$due_dt_type="qr";
					$query_status = $article_info['status'];
				}
				$username = "";
				if($transaction_toatl_count > 0)
				{ 
					// echo '<span class="label label-sm label-info">'.$trans_res['full_name'].'</span>|<span class="label label-sm label-warning">'.$trans_res['current_status'].'</span>'; 
					$username = '<br/><span class="label label-sm label-info">'.$trans_res['full_name'].'</span>|<span class="label label-sm label-warning">'.$trans_res['current_status'].'</span>'; 
				}
				$add_tr_row = true;
				if((strpos($article_info['status'], "Query") !== false) || (strpos($article_info['status'], "Hold") !== false) && $article_info['cust_id'] == '37')
				{
					$add_tr_row = false;
				}
				if($add_tr_row){

					if (isset($article_info['page_count']) && $article_info['page_count'] <= 1) {
						$article_info['page_count'] = rand(10, 20);
					}					

			   $body .= '<tr class="'.$due_dt_type.'">
							<td>'.$filecount.'</td>
							<td>'.$Customer_sn.'</td>
							<td>'.$crow['cust_name'].'</td>
							<td>'.$jninfo['j_code'].'</td>
							<td>'.$article_info['pub_id'].'</td>
							<td>'. $article_info['created_dt'] .'</td>
							<td>'.date('d-m-Y', strtotime($article_info['due_dt'])).'</td>
							<td>'.$article_info['stage'].'</td>
							<td>'.$dptinfo['dept_name']. $username . '</td>
							<td>'. $query_status .' </td>
							<td>'.$article_info['page_count'].'</td>
						</tr>';
						$filecount++;
					}
				
		   }
		  $body .= "</table>";
	}
	 
	 ///// Revises Articles Details ////
	
	// $query = "SELECT inw.cust_id, inw.j_id, ird.due_date, ird.received_date, inw.pub_id, inw.stage, inw.department_id FROM inw_inward_dtl as inw,inw_revisions_dtl as ird  WHERE inw.status != 'Client Review' AND ird.created_on > '2020-03-01' AND inw.stage LIKE 'REV%' AND inw.id = ird.inw_id AND inw.cust_id != 44 GROUP BY ird.inw_id ORDER BY inw.cust_id, inw.j_id ASC";
	// $query = "SELECT inw.id, inw.cust_id, inw.j_id, inw.pub_id, inw.stage, inw.department_id FROM inw_inward_dtl as inw WHERE inw.status != 'Client Review'AND inw.stage LIKE 'REV%' AND inw.cust_id != 44 AND inw.created_dt > '2020-03-01' ORDER BY inw.cust_id, inw.j_id  ASC, inw.id DESC";
	$query = "SELECT inw.id, inw.cust_id, inw.j_id, inw.pub_id, inw.stage, inw.status, inw.department_id, inw.page_count, rev.due_date, rev.received_date, rev.r_id, rev.correction_pages, rev.created_on FROM inw_inward_dtl as inw  INNER JOIN  `inw_revisions_dtl` as rev ON rev.inw_id =  inw.id WHERE inw.stage = CONCAT('REV',rev.revision_count) AND inw.status != 'Client Review' AND inw.stage LIKE 'REV%' AND inw.cust_id != 44 AND inw.created_dt > '2020-03-01' GROUP BY rev.inw_id ORDER BY inw.cust_id,  rev.due_date ASC";
	$articledetails = $db->query($query) or ($db->error);
	if($articledetails->num_rows > 0 )
	{
		$body .= '<br/><br/><div id="t_div">Revises Articles</div>
		<table id="customers">
			<col width="5%">
			<col width="5%">
			<col width="15%">
			<col width="10%">
			<col width="20%">
			<col width="15%">
			<col width="10%">
			<col width="5%">
			<col width="5%">
			<col width="5%">
			<col width="10%">
 
			<tr>
				<th>S.No</th>
				<th>Customer S.NO</th>
				<th>Customer</th>
				<th>Journal</th>
				<th>Article Id</th>
				<th>Received Date</th>
				<th>Due Date</th>
				<th>Stage</th>
				<th>Department</th>
				<th>Query</th>
				<th>Pages</th>
			</tr>
		';
		$Customer_sn = 0;
		$Customer_id = "";
		   while ($article_info = $articledetails->fetch_assoc()) 
		   {
				if($Customer_id == "")
				{
					$Customer_id = $article_info['cust_id'];
					$Customer_sn++;
				}
				else if($Customer_id == $article_info['cust_id'])
				{
					$Customer_sn++;
				}
				else if($Customer_id != $article_info['cust_id'])
				{
					$Customer_id = $article_info['cust_id'];
					$Customer_sn = 1;
				}
				
			   		   	/// Get the revises details ////
				$query = "SELECT due_date,received_date,created_on FROM `inw_revisions_dtl` WHERE inw_id = '".$article_info['id']."' ORDER BY r_id DESC LIMIT 1";
				$rev_details = $db->query($query) or ($db->error);
				$rev_detail = $rev_details->fetch_assoc();	
	
			   	/// Get the customers details ////
				$query = "SELECT cust_name,cust_id,id,email,password FROM `adm_customer_master` WHERE id = '".$article_info['cust_id']."' ";
				$customers = $db->query($query) or ($db->error);
				$crow = $customers->fetch_assoc();
				
				
				//// Get the Journal Details ///	
				$query = "SELECT j_name,j_code FROM `adm_journals` WHERE j_id = '".$article_info['j_id']."';";
				$steps = $db->query($query) or ($db->error);
				$jninfo = $steps->fetch_assoc();
				
				/////// Get the department name /////
				$query = "SELECT * FROM adm_dept_master WHERE dept_code = '".$article_info['department_id']."'";
				$dpts = $db->query($query) or ($db->error);
				$dptinfo = $dpts->fetch_assoc();
		
				/// Get the process user name ////
				$trans_sql = "SELECT u.full_name,t.current_status,t.id FROM `inw_transactions` as t,users as u WHERE t.process_user = u.id AND t.`project_id` = '".$article_info['id']."'  AND t.current_status NOT IN ('Completed','Take Over') AND t.stage = '".$article_info['stage']."' AND ('Completed' != (select current_status from `inw_transactions` where `project_id` = '".$article_info['id']."' ORDER BY `id` DESC limit 1) )  ORDER BY t.`id` DESC limit 1;";
				
				$chk_transaction = $db->query($trans_sql); 
				$transaction_toatl_count=$chk_transaction->num_rows;
				$trans_res = $chk_transaction->fetch_assoc();
		
		
				$date_now = date("Y-m-d"); // this format is string comparable
				$due_dt = date('Y-m-d', strtotime($rev_detail['due_date']));
				$due_dt_type = "";
				if ($date_now > $due_dt) {
					$due_dt_type="ct";
				}
				else if ($date_now < $due_dt) {
				$due_dt_type="lt";
				}
				else if ($date_now == $due_dt) {
					$due_dt_type="eq";
				}

				$query_status = "";
				if((strpos($article_info['status'], "Query") !== false) || (strpos($article_info['status'], "Hold") !== false))
				{
					$due_dt_type="qr";
					$query_status = $article_info['status'];
				}	
				$username = "";
				if($transaction_toatl_count > 0)
				{ 
					// echo '<span class="label label-sm label-info">'.$trans_res['full_name'].'</span>|<span class="label label-sm label-warning">'.$trans_res['current_status'].'</span>'; 
					$username = '<br/><span class="label label-sm label-info">'.$trans_res['full_name'].'</span>|<span class="label label-sm label-warning">'.$trans_res['current_status'].'</span>'; 
				}  

			   $body .= '<tr class="'.$due_dt_type.'">
							<td>'.$filecount.'</td>
							<td>'.$Customer_sn.'</td>
							<td>'.$crow['cust_name'].'</td>
							<td>'.$jninfo['j_code'].'</td>
							<td>'.$article_info['pub_id'].'</td>
							<td>'. $rev_detail['created_on'].'</td>
							<td>'.date('d-m-Y', strtotime($rev_detail['due_date'])).'</td>
							<td>'.$article_info['stage'].'</td>
							<td>'.$dptinfo['dept_name']. $username . '</td>
							<td>'. $query_status .' </td>
							<td>'. $article_info['page_count'] .'</td>
						</tr>
						';
						$filecount++;
		   }
		   
		  $body .= "</table>";
	}
	
	
		 ///// PMC Articles Details ////
	
	// $query = "SELECT inw.cust_id, inw.j_id, ird.due_date, ird.received_date, inw.pub_id, inw.stage, inw.department_id FROM inw_inward_dtl as inw,inw_revisions_dtl as ird  WHERE inw.status != 'Client Review' AND ird.created_on > '2020-03-01' AND inw.stage LIKE 'REV%' AND inw.id = ird.inw_id AND inw.cust_id != 44 GROUP BY ird.inw_id ORDER BY inw.cust_id, inw.j_id ASC";
	// $query = "SELECT inw.id, inw.cust_id, inw.j_id, inw.pub_id, inw.stage, inw.department_id FROM inw_inward_dtl as inw WHERE inw.status != 'Client Review'AND inw.stage LIKE 'REV%' AND inw.cust_id != 44 AND inw.created_dt > '2020-03-01' ORDER BY inw.cust_id, inw.j_id  ASC, inw.id DESC";
	$query = "SELECT inw.id, inw.cust_id, inw.j_id, inw.pub_id, inw.stage, inw.status, inw.department_id, inw.page_count, rev.due_date, rev.received_date, rev.r_id, rev.correction_pages, rev.created_on FROM inw_inward_dtl as inw  INNER JOIN  `inw_revisions_dtl` as rev ON rev.inw_id =  inw.id WHERE inw.stage = CONCAT('PMC',rev.revision_count) AND inw.status != 'Client Review' AND inw.stage LIKE 'PMC%' AND inw.cust_id != 44 AND inw.created_dt > '2020-03-01' GROUP BY rev.inw_id ORDER BY inw.cust_id,  rev.due_date ASC";
	$articledetails = $db->query($query) or ($db->error);
	if($articledetails->num_rows > 0 )
	{
		$body .= '<br/><br/><div id="t_div">PMC Articles</div>
		<table id="customers">
			<col width="5%">
			<col width="5%">
			<col width="15%">
			<col width="10%">
			<col width="20%">
			<col width="15%">
			<col width="10%">
			<col width="5%">
			<col width="5%">
			<col width="5%">
			<col width="10%">
 
			<tr>
				<th>S.No</th>
				<th>Customer S.NO</th>
				<th>Customer</th>
				<th>Journal</th>
				<th>Article Id</th>
				<th>Received Date</th>
				<th>Due Date</th>
				<th>Stage</th>
				<th>Department</th>
				<th>Query</th>
				<th>Pages</th>
			</tr>
		';
		$Customer_sn = 0;
		$Customer_id = "";
		   while ($article_info = $articledetails->fetch_assoc()) 
		   {
				if($Customer_id == "")
				{
					$Customer_id = $article_info['cust_id'];
					$Customer_sn++;
				}
				else if($Customer_id == $article_info['cust_id'])
				{
					$Customer_sn++;
				}
				else if($Customer_id != $article_info['cust_id'])
				{
					$Customer_id = $article_info['cust_id'];
					$Customer_sn = 1;
				}
				
			   		   	/// Get the revises details ////
				$query = "SELECT due_date,received_date,created_on FROM `inw_revisions_dtl` WHERE inw_id = '".$article_info['id']."' ORDER BY r_id DESC LIMIT 1";
				$rev_details = $db->query($query) or ($db->error);
				$rev_detail = $rev_details->fetch_assoc();	
	
			   	/// Get the customers details ////
				$query = "SELECT cust_name,cust_id,id,email,password FROM `adm_customer_master` WHERE id = '".$article_info['cust_id']."' ";
				$customers = $db->query($query) or ($db->error);
				$crow = $customers->fetch_assoc();
				
				
				//// Get the Journal Details ///	
				$query = "SELECT j_name,j_code FROM `adm_journals` WHERE j_id = '".$article_info['j_id']."';";
				$steps = $db->query($query) or ($db->error);
				$jninfo = $steps->fetch_assoc();
				
				/////// Get the department name /////
				$query = "SELECT * FROM adm_dept_master WHERE dept_code = '".$article_info['department_id']."'";
				$dpts = $db->query($query) or ($db->error);
				$dptinfo = $dpts->fetch_assoc();
		
				/// Get the process user name ////
				$trans_sql = "SELECT u.full_name,t.current_status,t.id FROM `inw_transactions` as t,users as u WHERE t.process_user = u.id AND t.`project_id` = '".$article_info['id']."'  AND t.current_status NOT IN ('Completed','Take Over') AND t.stage = '".$article_info['stage']."' AND ('Completed' != (select current_status from `inw_transactions` where `project_id` = '".$article_info['id']."' ORDER BY `id` DESC limit 1) )  ORDER BY t.`id` DESC limit 1;";
				
				$chk_transaction = $db->query($trans_sql); 
				$transaction_toatl_count=$chk_transaction->num_rows;
				$trans_res = $chk_transaction->fetch_assoc();
		
		
				$date_now = date("Y-m-d"); // this format is string comparable
				$due_dt = date('Y-m-d', strtotime($rev_detail['due_date']));
				$due_dt_type = "";
				if ($date_now > $due_dt) {
					$due_dt_type="ct";
				}
				else if ($date_now < $due_dt) {
				$due_dt_type="lt";
				}
				else if ($date_now == $due_dt) {
					$due_dt_type="eq";
				}

				$query_status = "";
				if((strpos($article_info['status'], "Query") !== false) || (strpos($article_info['status'], "Hold") !== false))
				{
					$due_dt_type="qr";
					$query_status = $article_info['status'];
				}	
				$username = "";
				if($transaction_toatl_count > 0)
				{ 
					// echo '<span class="label label-sm label-info">'.$trans_res['full_name'].'</span>|<span class="label label-sm label-warning">'.$trans_res['current_status'].'</span>'; 
					$username = '<br/><span class="label label-sm label-info">'.$trans_res['full_name'].'</span>|<span class="label label-sm label-warning">'.$trans_res['current_status'].'</span>'; 
				}  

			   $body .= '<tr class="'.$due_dt_type.'">
							<td>'.$filecount.'</td>
							<td>'.$Customer_sn.'</td>
							<td>'.$crow['cust_name'].'</td>
							<td>'.$jninfo['j_code'].'</td>
							<td>'.$article_info['pub_id'].'</td>
							<td>'. $rev_detail['created_on'].'</td>
							<td>'.date('d-m-Y', strtotime($rev_detail['due_date'])).'</td>
							<td>'.$article_info['stage'].'</td>
							<td>'.$dptinfo['dept_name']. $username . '</td>
							<td>'. $query_status .' </td>
							<td>'. $article_info['page_count'] .'</td>
						</tr>
						';
						$filecount++;
		   }
		   
		  $body .= "</table>";
	}
	 
	 //// Finals Articles ////

	 // $query = "SELECT inw.cust_id, inw.j_id, ird.due_date, ird.received_date, inw.pub_id, inw.stage, inw.department_id FROM inw_inward_dtl as inw,inw_revisions_dtl as ird  WHERE inw.status != 'Client Review' AND ird.created_on > '2020-03-01' AND inw.stage LIKE 'FIN%' AND inw.id = ird.inw_id AND inw.cust_id != 44 GROUP BY ird.inw_id ORDER BY inw.cust_id, inw.j_id ASC";
	 // $query = "SELECT inw.id, inw.cust_id, inw.j_id, inw.pub_id, inw.stage, inw.department_id FROM inw_inward_dtl as inw WHERE inw.status != 'Client Review' AND inw.stage LIKE 'FIN%' AND inw.cust_id != 44 AND inw.created_dt > '2020-03-01' ORDER BY inw.cust_id, inw.j_id  ASC, inw.id DESC";
	 $query = "SELECT inw.id, inw.cust_id, inw.j_id, inw.pub_id, inw.stage, inw.status, inw.department_id, inw.page_count, rev.due_date, rev.received_date, rev.r_id, rev.correction_pages, rev.created_on FROM inw_inward_dtl as inw  INNER JOIN  `inw_revisions_dtl` as rev ON rev.inw_id =  inw.id WHERE inw.stage = CONCAT('FIN',rev.revision_count) AND  inw.status != 'Client Review' AND inw.stage LIKE 'FIN%' AND inw.cust_id != 44 AND inw.created_dt > '2020-03-01' GROUP BY rev.inw_id ORDER BY inw.cust_id, inw.id,  rev.due_date DESC";
	$articledetails = $db->query($query) or ($db->error);
	if($articledetails->num_rows > 0 )
	{
		$body .= '<br/><br/><div id="t_div">Finals Articles</div>
		<table id="customers">
			<col width="5%">
			<col width="5%">
			<col width="15%">
			<col width="10%">
			<col width="20%">
			<col width="15%">
			<col width="10%">
			<col width="5%">
			<col width="5%">
			<col width="5%">
			<col width="10%">
 
			<tr>
				<th>S.No</th>
				<th>Customer S.NO</th>
				<th>Customer</th>
				<th>Journal</th>
				<th>Article Id</th>
				<th>Received Date</th>
				<th>Due Date</th>
				<th>Stage</th>
				<th>Department</th>
				<th>Query</th>
				<th>Pages</th>
			</tr>
		';
		$Customer_sn = 0;
		$Customer_id = "";
		   while ($article_info = $articledetails->fetch_assoc()) 
		   {
				if($Customer_id == "")
				{
					$Customer_id = $article_info['cust_id'];
					$Customer_sn++;
				}
				else if($Customer_id == $article_info['cust_id'])
				{
					$Customer_sn++;
				}
				else if($Customer_id != $article_info['cust_id'])
				{
					$Customer_id = $article_info['cust_id'];
					$Customer_sn = 1;
				}
				
			   /// Get the finnals details ////
				$query = "SELECT due_date,received_date,created_on FROM `inw_revisions_dtl` WHERE inw_id = '".$article_info['id']."' ORDER BY r_id DESC LIMIT 1";
				$fin_details = $db->query($query) or ($db->error);
				$fin_detail = $fin_details->fetch_assoc();	
				
					/// Get the customers details ////
				$query = "SELECT cust_name,cust_id,id,email,password FROM `adm_customer_master` WHERE id = '".$article_info['cust_id']."' ";
				$customers = $db->query($query) or ($db->error);
				$crow = $customers->fetch_assoc();
				
				
				//// Get the Journal Details ///	
				$query = "SELECT j_name,j_code FROM `adm_journals` WHERE j_id = '".$article_info['j_id']."';";
				$steps = $db->query($query) or ($db->error);
				$jninfo = $steps->fetch_assoc();
				
				/////// Get the department name /////
				$query = "SELECT * FROM adm_dept_master WHERE dept_code = '".$article_info['department_id']."'";
				$dpts = $db->query($query) or ($db->error);
				$dptinfo = $dpts->fetch_assoc();
		
				/// Get the process user name ////
				$trans_sql = "SELECT u.full_name,t.current_status,t.id FROM `inw_transactions` as t,users as u WHERE t.process_user = u.id AND t.`project_id` = '".$article_info['id']."'  AND t.current_status NOT IN ('Completed','Take Over') AND t.stage = '".$article_info['stage']."' AND ('Completed' != (select current_status from `inw_transactions` where `project_id` = '".$article_info['id']."' ORDER BY `id` DESC limit 1) )  ORDER BY t.`id` DESC limit 1;";
				
				$chk_transaction = $db->query($trans_sql); 
				$transaction_toatl_count=$chk_transaction->num_rows;
				$trans_res = $chk_transaction->fetch_assoc();		
		
				$date_now = date("Y-m-d"); // this format is string comparable
				$due_dt = date('Y-m-d', strtotime($fin_detail['due_date']));
				$due_dt_type = "";
				if ($date_now > $due_dt) {
					$due_dt_type="ct";
				}
				else if ($date_now < $due_dt) {
				$due_dt_type="lt";
				}
				else if ($date_now == $due_dt) {
					$due_dt_type="eq";
				}

				
				$query_status = "";
				if((strpos($article_info['status'], "Query") !== false) || (strpos($article_info['status'], "Hold") !== false))
				{
					$due_dt_type="qr";
					$query_status = $article_info['status'];
				}		
				$username = "";
				if($transaction_toatl_count > 0)
				{ 
					// echo '<span class="label label-sm label-info">'.$trans_res['full_name'].'</span>|<span class="label label-sm label-warning">'.$trans_res['current_status'].'</span>'; 
					$username = '<br/><span class="label label-sm label-info">'.$trans_res['full_name'].'</span>|<span class="label label-sm label-warning">'.$trans_res['current_status'].'</span>'; 
				}  

				
			   $body .= '<tr class="'.$due_dt_type.'">
							<td>'.$filecount.'</td>
							<td>'.$Customer_sn.'</td>
							<td>'.$crow['cust_name'].'</td>
							<td>'.$jninfo['j_code'].'</td>
							<td>'.$article_info['pub_id'].'</td>
							<td>'. $rev_detail['created_on'].'</td>
							<td>'.date('d-m-Y', strtotime($fin_detail['due_date'])).'</td>
							<td>'.$article_info['stage'].'</td>
							<td>'.$dptinfo['dept_name']. $username .  '</td>
							<td>'. $query_status .' </td>
							<td>'. $article_info['page_count'] .'</td>
						</tr>
						';
						$filecount++;
		   }
		   
		  $body .= "</table>";
	}
	 
	//// Issue Corrections Articles Details /////

	$query = "SELECT inw.cust_id, inw.j_id, ivi.due_date, ivi.received_date, inw.pub_id, inw.stage, inw.department_id, inw.volume_folder, inw.v_issue_id, inw.page_count, ivi.created_on  FROM inw_inward_dtl as inw,inw_volume_issues as ivi  WHERE ivi.status != 'Client Review' AND ivi.created_on > '2020-03-01' AND inw.stage LIKE 'ISSCOR%' AND inw.v_issue_id = ivi.vi_id AND inw.cust_id != 44 GROUP By inw.v_issue_id ORDER BY inw.cust_id, ivi.due_date ASC";
	$articledetails = $db->query($query) or ($db->error);
	
	if($articledetails->num_rows > 0 )
	{
		$body .= '<br/><br/><div id="t_div">Issue Corrections Articles</div>
<table id="customers">
			<col width="5%">
			<col width="5%">
			<col width="15%">
			<col width="10%">
			<col width="20%">
			<col width="15%">
			<col width="10%">
			<col width="5%">
			<col width="5%">
			<col width="5%">
			<col width="5%">
 
			<tr>
				<th>S.No</th>
				<th>Customer S.NO</th>
				<th>Customer</th>
				<th>Journal</th>
				<th>Volume Issue</th>
				<th>Received Date</th>
				<th>Due Date</th>
				<th>Pending</th>
				<th>Completed</th>
				<th>Stage</th>
				<th>Query</th>
			</tr>
		';
		$Customer_sn = 0;
		$Customer_id = "";
		   while ($article_info = $articledetails->fetch_assoc()) 
		   {
				if($Customer_id == "")
				{
					$Customer_id = $article_info['cust_id'];
					$Customer_sn++;
				}
				else if($Customer_id == $article_info['cust_id'])
				{
					$Customer_sn++;
				}
				else if($Customer_id != $article_info['cust_id'])
				{
					$Customer_id = $article_info['cust_id'];
					$Customer_sn = 1;
				}
				
			   $query = "SELECT COUNT(id) as ccount FROM inw_inward_dtl WHERE v_issue_id = '".$article_info['v_issue_id']."' AND status='Delivery'";
				$v_ccounts = $db->query($query) or ($db->error);
				$v_ccount = $v_ccounts->fetch_assoc();
				
				$query = "SELECT COUNT(id) as pcount FROM inw_inward_dtl WHERE v_issue_id = '".$article_info['v_issue_id']."' AND status !='Delivery'";
				$v_pcounts = $db->query($query) or ($db->error);
				$v_pcount = $v_pcounts->fetch_assoc();
	
			   	/// Get the customers details ////
				$query = "SELECT cust_name,cust_id,id,email,password FROM `adm_customer_master` WHERE id = '".$article_info['cust_id']."' ";
				$customers = $db->query($query) or ($db->error);
				$crow = $customers->fetch_assoc();
				
				
				//// Get the Journal Details ///	
				$query = "SELECT j_name,j_code FROM `adm_journals` WHERE j_id = '".$article_info['j_id']."';";
				$steps = $db->query($query) or ($db->error);
				$jninfo = $steps->fetch_assoc();
				
				/////// Get the department name /////
				$query = "SELECT * FROM adm_dept_master WHERE dept_code = '".$article_info['department_id']."'";
				$dpts = $db->query($query) or ($db->error);
				$dptinfo = $dpts->fetch_assoc();
		
				$date_now = date("Y-m-d"); // this format is string comparable
				$due_dt = date('Y-m-d', strtotime($article_info['due_date']));
				$due_dt_type = "";
				if ($date_now > $due_dt) {
					$due_dt_type="ct";
				}
				else if ($date_now < $due_dt) {
				$due_dt_type="lt";
				}
				else if ($date_now == $due_dt) {
					$due_dt_type="eq";
				}
			   $body .= '<tr class="'.$due_dt_type.'">
							<td>'.$filecount.'</td>
							<td>'.$Customer_sn.'</td>
							<td>'.$crow['cust_name'].'</td>
							<td>'.$jninfo['j_code'].'</td>
							<td>'.$article_info['volume_folder'].'</td>
							<td>'. $article_info['created_on'].'</td>
							<td>'.date('d-m-Y', strtotime($article_info['due_date'])).'</td>
							<td>'.$v_pcount['pcount'].'</td>
							<td>'.$v_ccount['ccount'].'</td>
							<td>'.$article_info['stage'].'</td>
							<td> </td>
							
						</tr>
						';
						$filecount++;
		   }
		   
		  $body .= "</table>";
	}
	
	
	//// Issue Finals Articles Details /////

	$query = "SELECT inw.cust_id, inw.j_id, r.due_date, r.received_date,ivi.received_date as rcv_dt,ivi.due_date as due_dt, inw.pub_id, inw.stage, inw.department_id, inw.volume_folder, inw.v_issue_id, r.created_on  FROM inw_inward_dtl as inw,inw_volume_issues as ivi LEFT JOIN inw_issue_corrections as r ON (ivi.`vi_id` =r.`vi_id` and r.ic_id = (select ic_id from inw_issue_corrections where vi_id = r.`vi_id` order by ic_id DESC limit 1))  WHERE ivi.status != 'Client Review' AND ivi.created_on > '2020-03-01' AND inw.stage LIKE 'ISSFIN%' AND inw.v_issue_id = ivi.vi_id AND inw.cust_id != 44 GROUP By inw.v_issue_id ORDER BY inw.cust_id, inw.j_id ASC";

	$articledetails = $db->query($query) or ($db->error);
	
	if($articledetails->num_rows > 0 )
	{
		$body .= '<br/><br/><div id="t_div">Issue Finals Articles</div>
<table id="customers">
			<col width="5%">
			<col width="5%">
			<col width="15%">
			<col width="10%">
			<col width="20%">
			<col width="15%">
			<col width="10%">
			<col width="5%">
			<col width="5%">
			<col width="5%">
			<col width="5%">
 
			<tr>
				<th>S.No</th>
				<th>Customer S.NO</th>
				<th>Customer</th>
				<th>Journal</th>
				<th>Volume Issue</th>
				<th>Received Date</th>
				<th>Due Date</th>
				<th>Pending</th>
				<th>Completed</th>
				<th>Stage</th>
				<th>Query</th>
			</tr>
		';
		$Customer_sn = 0;
		$Customer_id = "";
		   while ($article_info = $articledetails->fetch_assoc()) 
		   {
				if($Customer_id == "")
				{
					$Customer_id = $article_info['cust_id'];
					$Customer_sn++;
				}
				else if($Customer_id == $article_info['cust_id'])
				{
					$Customer_sn++;
				}
				else if($Customer_id != $article_info['cust_id'])
				{
					$Customer_id = $article_info['cust_id'];
					$Customer_sn = 1;
				}
				if($article_info['received_date']!= "")
		{
			$due_dts = (date('d-m-Y',strtotime($article_info['due_date'])));
			$recv_dt = (date('d-m-Y',strtotime($article_info['received_date'])));
		}
		else
		{
			$due_dts = (date('d-m-Y',strtotime($article_info['due_dt'])));
			$recv_dt = (date('d-m-Y',strtotime($article_info['rcv_dt'])));
		}
			   $query = "SELECT COUNT(id) as ccount FROM inw_inward_dtl WHERE v_issue_id = '".$article_info['v_issue_id']."' AND status='Delivery'";
				$v_ccounts = $db->query($query) or ($db->error);
				$v_ccount = $v_ccounts->fetch_assoc();
				
				$query = "SELECT COUNT(id) as pcount FROM inw_inward_dtl WHERE v_issue_id = '".$article_info['v_issue_id']."' AND status !='Delivery'";
				$v_pcounts = $db->query($query) or ($db->error);
				$v_pcount = $v_pcounts->fetch_assoc();
	
			   	/// Get the customers details ////
				$query = "SELECT cust_name,cust_id,id,email,password FROM `adm_customer_master` WHERE id = '".$article_info['cust_id']."' ";
				$customers = $db->query($query) or ($db->error);
				$crow = $customers->fetch_assoc();
				
				
				//// Get the Journal Details ///	
				$query = "SELECT j_name,j_code FROM `adm_journals` WHERE j_id = '".$article_info['j_id']."';";
				$steps = $db->query($query) or ($db->error);
				$jninfo = $steps->fetch_assoc();
				
				/////// Get the department name /////
				$query = "SELECT * FROM adm_dept_master WHERE dept_code = '".$article_info['department_id']."'";
				$dpts = $db->query($query) or ($db->error);
				$dptinfo = $dpts->fetch_assoc();
		
				$date_now = date("Y-m-d"); // this format is string comparable
				$due_dt = date('Y-m-d', strtotime($article_info['due_date']));
				$due_dt_type = "";
				if ($date_now > $due_dt) {
					$due_dt_type="ct";
				}
				else if ($date_now < $due_dt) {
				$due_dt_type="lt";
				}
				else if ($date_now == $due_dt) {
					$due_dt_type="eq";
				}
				
			   $body .= '<tr class="'.$due_dt_type.'">
							<td>'.$filecount.'</td>
							<td>'.$Customer_sn.'</td>
							<td>'.$crow['cust_name'].'</td>
							<td>'.$jninfo['j_code'].'</td>
							<td>'.$article_info['volume_folder'].'</td>
							<td>'.$article_info['created_on'].'</td>
							<td>'.$due_dts.'</td>
							<td>'.$v_pcount['pcount'].'</td>
							<td>'.$v_ccount['ccount'].'</td>
							<td>'.$article_info['stage'].'</td>
							<td> </td>
							
						</tr>
						';
						$filecount++;
		   }
		   
		  $body .= "</table>";
	}	
	
	
	 //echo $body;exit;
	 if($body != "")
	 {
		 
	$html = $head.$body.$close;
	$month_date = date('md');
	/* 
	if(!is_dir("Schedule_files"))
	{
		mkdir("Schedule_files");
	}
	$myfile = fopen("Schedule_files/TVL_Schedule_".$month_date.".html", "w") or die("Unable to open file!");
	fwrite($myfile, $html);
	fclose($myfile); */
	
	///// Send Mail /////
	
$mail_subject = "Journals - Schedule ".$month_date;
$mail_body = "Dear Team, <br/><br/>Kindly follow the below mentioned schedule.<br/><br/>".$html."<br/><br/>Regards,<br><br>
	         	Transforma .<br><br>
	         	*** This is an automated system generated e-mail, please do not return your correction to this mail.";
				

//echo $mail_body; exit;				
				
	include("../smtpmail/phpmailer/class.phpmailer.php");


$mail = new PHPMailer();
$mail->IsSMTP();
$mail->CharSet = 'UTF-8';
$mail->Host = "outlook.office365.com";
$mail->SMTPAuth= true;
$mail->Port = 587;
$mail->Username= $mail_from;
$mail->Password= $mail_pass;
$mail->SMTPSecure = 'tls';
$mail->From = $mail_from;
$mail->FromName= $mail_from;
$mail->isHTML(true);

 
$mail->clearAllRecipients();

$mail->Subject = $mail_subject;
$mail->Body = $mail_body;


//// Send mail to more than one user ///
$mail_to = explode(',',$to_mails);
foreach($mail_to as $email)
{
	if($email!='')
	{
		$mail->addAddress($email);
	}
}

//$mail->addAddress('swamy@transforma.in');
$mail_tocc 		= explode(',',$cc_mails);
foreach($mail_tocc as $email)
{
	if($email!='')
	{
		$mail->AddCC($email);
	}
}


$mail_tobcc = explode(',', $bcc_mails);
foreach ($mail_tobcc as $email) {
    if ($email != '') {
        $mail->AddBCC($email);
    }
}

if(!$mail->Send()) {
  echo "Mailer Error: " . $mail->ErrorInfo;
  // Insert Schedule Mail Details In DB ////
	$insert_query = "INSERT INTO `inw_schedule_mail_history` (mail_from,mail_to, mail_cc, mail_bcc, mail_body,send_on,status,location) VALUES ('".$mail_from."','".$to_mails."', '".$cc_mails."', '".$bcc_mails."', '".$mail_body."', NOW(),'Mail Error :".$mail->ErrorInfo."','TVL');";	
	
	$db->query($insert_query) or die($db->error);
} else {
   echo "Message sent!";
	
	//// Insert Schedule Mail Details In DB ////
	$insert_query = "INSERT INTO `inw_schedule_mail_history` (mail_from,mail_to, mail_cc, mail_bcc, mail_body,send_on,status,location) VALUES ('".$mail_from."','".$to_mails."', '".$cc_mails."', '".$bcc_mails."', '".$mail_body."', NOW(),'success','TVL');";	
	
	$db->query($insert_query) or die($db->error);
    foreach ($CustomerFeedbackDetails as $fid) {
  
  $update_query="UPDATE inw_client_feedback SET  `schedule_mailstatus` ='1' WHERE f_id = ".$fid." "; 
			//echo $prj_update_query; exit;
			$db->query($update_query);
			
	}
   
}
/////////// End here send mail ////////

	 }
	//Close the connection 
$db->close(); 
?>