Option Explicit

Dim shell, nextRun, nowTime

Set shell = CreateObject("WScript.Shell")

Do
    nowTime = Time()

    ' --- 10:30 AM ---
    If nowTime >= #10:30:00 AM# And nowTime < #10:31:00 AM# Then
        shell.Run """D:\Localserver\Apache\htdocs\workflow-new\daily-reports\TVL_due_scheduler.bat""", 0, True
        WScript.Sleep 60000  ' wait 1 minute to avoid double run
    End If

    ' --- 3:30 PM ---
    If nowTime >= #3:30:00 PM# And nowTime < #3:31:00 PM# Then
        shell.Run """D:\Localserver\Apache\htdocs\workflow-new\daily-reports\TVL_due_scheduler.bat""", 0, True
        WScript.Sleep 60000
    End If

    ' --- 8:30 PM ---
    If nowTime >= #8:30:00 PM# And nowTime < #8:31:00 PM# Then
        shell.Run """D:\Localserver\Apache\htdocs\workflow-new\daily-reports\TVL_due_scheduler.bat""", 0, True
        WScript.Sleep 60000
    End If

    ' Check every 20 seconds
    WScript.Sleep 20000

Loop