@echo off
SET PHP_EXE="D:\Localserver\php\php.exe"
SET SCRIPT="D:\Localserver\Apache\htdocs\workflow-new\daily-reports\TVL_due_articles.php"

SET LOG_DIR="D:\Localserver\Apache\htdocs\workflow-new\daily-reports\logs"
SET LOG_FILE=%LOG_DIR%\tvl_due_log_%date:~10,4%-%date:~4,2%-%date:~7,2%.txt"

REM Create log folder if not exists
if not exist %LOG_DIR% mkdir %LOG_DIR%

echo ================================================ 
echo   TVL DUE ARTICLE CRON SCRIPT
echo   RUN STARTED at %date% %time%
echo ================================================ 

echo [%date% %time%] Script STARTED by VBS scheduler >> %LOG_FILE%

REM --- Run the PHP script ---
%PHP_EXE% %SCRIPT%

echo [%date% %time%] Script COMPLETED successfully >> %LOG_FILE%
echo ================================================ 
echo   SCRIPT FINISHED
echo ================================================ 

exit /b
